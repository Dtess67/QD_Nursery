# baseline_v1 summary

- Records: 36
- Completed: 36
- Errors: 0

This is descriptive baseline evidence. It does not certify correctness.

| Case | Lane | Dimension | Completed | Assessor outcomes | Final outcomes | Final confidence | Evidence sets |
|---|---|---|---:|---:|---:|---|---:|
| `causal_attribution_shuffle_order_01` | controlled | shuffle_stability | 2/2 | 2 | 1 | 0.850–0.850 | 1 |
| `causal_attribution_shuffle_order_02` | controlled | shuffle_stability | 2/2 | 2 | 2 | 0.300–0.750 | 1 |
| `causal_attribution_shuffle_order_03` | controlled | shuffle_stability | 2/2 | 2 | 2 | 0.650–0.750 | 1 |
| `causal_attribution_shuffle_order_04` | controlled | shuffle_stability | 2/2 | 2 | 2 | 0.400–0.750 | 1 |
| `causal_attribution_shuffle_order_05` | controlled | shuffle_stability | 2/2 | 2 | 2 | 0.750–0.850 | 1 |
| `causal_attribution_shuffle_order_06` | controlled | shuffle_stability | 2/2 | 2 | 2 | 0.300–0.850 | 1 |
| `compound_eiffel` | live | compound_claim | 2/2 | 2 | 1 | 0.850–0.850 | 1 |
| `contested_alcohol_health` | live | genuine_contested_claim | 2/2 | 2 | 1 | 0.750–0.750 | 2 |
| `duplicate_family_single` | controlled | duplicate_source_families | 2/2 | 2 | 1 | 0.850–0.850 | 1 |
| `duplicate_family_triplicate` | controlled | duplicate_source_families | 2/2 | 2 | 1 | 0.850–0.850 | 1 |
| `loaded_wording_neutral` | live | loaded_claim_wording | 2/2 | 1 | 1 | 0.750–0.750 | 1 |
| `loaded_wording_prefaced` | live | loaded_claim_wording | 2/2 | 2 | 1 | 0.750–0.750 | 1 |
| `neutral_reporting_rumor` | live | neutral_reporting | 2/2 | 2 | 2 | 0.750–0.850 | 1 |
| `outdated_eiffel_tallest` | live | outdated_evidence | 2/2 | 2 | 2 | 0.850–0.950 | 1 |
| `quotation_without_endorsement` | live | quotation_without_endorsement | 2/2 | 2 | 2 | 0.750–0.850 | 2 |
| `satire_fiction_turtle` | live | satire | 2/2 | 2 | 1 | 0.000–0.000 | 1 |
| `simple_refuted_flat_earth` | live | simple_false_claim | 2/2 | 2 | 1 | 0.950–0.950 | 1 |
| `simple_supported_water` | live | simple_supported_fact | 2/2 | 2 | 2 | 0.750–0.850 | 2 |

## Interpretation guardrails

- Assessor outcomes expose funnel behavior even when the Falsifier later masks it.
- Different live evidence-set hashes show retrieval variance, not automatically model inconsistency.
- Different outcomes with one fixed evidence set show kernel/model variance.
- Different outcomes across shuffle orders are evidence of possible path dependence.
- Single versus triplicate duplicate-family results expose whether repetition changes the outcome or confidence.
- Expected failures are baseline observations, not regressions.
